package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class MentorCurrentTraining {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
		private String technology;
		private int completedduration;
		private int pendingduration;
		
		@ManyToOne()
		@JoinColumn(name="username")
		private User username;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getTechnology() {
			return technology;
		}

		public void setTechnology(String technology) {
			this.technology = technology;
		}

		public int getCompletedduration() {
			return completedduration;
		}

		public void setCompletedduration(int completedduration) {
			this.completedduration = completedduration;
		}

		public int getPendingduration() {
			return pendingduration;
		}

		public void setPendingduration(int pendingduration) {
			this.pendingduration = pendingduration;
		}

		public User getUsername() {
			return username;
		}

		public void setUsername(User username) {
			this.username = username;
		}

		
		
}
