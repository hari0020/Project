export class AdminBlockUser {
    public username:string;
    public email:string;
}