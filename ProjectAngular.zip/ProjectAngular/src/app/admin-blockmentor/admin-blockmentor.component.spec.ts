import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBlockmentorComponent } from './admin-blockmentor.component';

describe('AdminBlockmentorComponent', () => {
  let component: AdminBlockmentorComponent;
  let fixture: ComponentFixture<AdminBlockmentorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminBlockmentorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminBlockmentorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
