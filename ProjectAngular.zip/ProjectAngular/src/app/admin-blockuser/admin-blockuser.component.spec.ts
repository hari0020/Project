import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBlockuserComponent } from './admin-blockuser.component';

describe('AdminBlockuserComponent', () => {
  let component: AdminBlockuserComponent;
  let fixture: ComponentFixture<AdminBlockuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminBlockuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminBlockuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
