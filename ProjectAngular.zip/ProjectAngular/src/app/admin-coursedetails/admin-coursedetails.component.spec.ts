import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCoursedetailsComponent } from './admin-coursedetails.component';

describe('AdminCoursedetailsComponent', () => {
  let component: AdminCoursedetailsComponent;
  let fixture: ComponentFixture<AdminCoursedetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCoursedetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCoursedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
