import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-coursedetails',
  templateUrl: './admin-coursedetails.component.html',
  styleUrls: ['./admin-coursedetails.component.css']
})
export class AdminCoursedetailsComponent implements OnInit {

  constructor() { }
  room: number = 1;

  ngOnInit() {
  }

  education_fields() {

    this.room++;
    var objTo = document.getElementById('education_fields')
    var divtest = document.createElement("div");
    divtest.setAttribute("class", "form-group removeclass" + this.room);
    var rdiv = 'removeclass' + this.room;
    divtest.innerHTML =
      '<div class="col-sm-4 nopadding">' +
      '<div class="form-group">' +
      '<input type="text" class="form-control" id="Degree" name="Degree[]" value="" placeholder="Technology">' +
      '</div>' +
      '</div>' +

      '<div class="col-sm-4 nopadding">' +
      '<div class="form-group">' +
      '<input type="text" class="form-control" id="Fee" name="Fee[]" value="" placeholder="Fee (in Rs.)">' +
      '</div>' +
      '</div>' +

      '<div class="col-sm-4 nopadding">' +
      '<div class="form-group">' +
      '<div class="input-group">' +
      '<input type="text" class="form-control" id="Duration" name="Duration[]" value="" placeholder="Duration (in days)">' +
      '<div class="input-group-btn">' +
      '<button class="btn btn-danger" type="button" (click)="remove_education_fields(' + this.room + ');"> ' +
      '<span class="glyphicon glyphicon-minus" aria-hidden="true"></span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div class="clear"></div>' +

      '</div>'
    objTo.appendChild(divtest)

  }
  remove_education_fields(rid) {
    $('.removeclass' + rid).remove();
  }
}
