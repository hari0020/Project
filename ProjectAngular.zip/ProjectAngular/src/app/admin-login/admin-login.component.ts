import { Component, OnInit } from '@angular/core';
import swal from 'sweetalert';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  email: string;
  pass: string;

  constructor(private adminlogin: Router) { }

  ngOnInit() {
  }

  submit() {
    if (this.email == null) {
      swal("", "Email is required", "error");
    }
    else if (this.pass == null) {
      swal("", "Password is required", "error");
    }
    else {
      this.adminlogin.navigate(['/admin-blockuser']);
    }
  }
}
