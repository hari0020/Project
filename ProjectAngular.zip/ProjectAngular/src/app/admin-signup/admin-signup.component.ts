import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';

@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrls: ['./admin-signup.component.css']
})
export class AdminSignupComponent implements OnInit {
  name:string;
  email:string;
  pass:string;
  pass1:string;

  constructor(private adminsignup: Router) { }

  ngOnInit() {
  }

  submit() {
    if(this.name==null) {
      swal("","Name is required","error");
    }
    else if(this.email==null) {
      swal("","Email is required","error");
    }
    else if(this.pass==null) {
      swal("","Password is required","error");
    }
    else if(this.pass!=this.pass1) {
      swal("","Password does not match","error");
    }
    else {
      this.adminsignup.navigate(['/admin-login']);
    }
  }
}
