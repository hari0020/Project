import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainPageComponent } from './main-page/main-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { AdminSignupComponent } from './admin-signup/admin-signup.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { AdminBlockuserComponent } from './admin-blockuser/admin-blockuser.component';
import { AdminBlockmentorComponent } from './admin-blockmentor/admin-blockmentor.component';
import { AdminCoursedetailsComponent } from './admin-coursedetails/admin-coursedetails.component';
import { UserInprogressComponent } from './user-inprogress/user-inprogress.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorInprogressComponent } from './mentor-inprogress/mentor-inprogress.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorEditskillsComponent } from './mentor-editskills/mentor-editskills.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';


const routes: Routes = [
  { path:'', redirectTo:'/main-page', pathMatch:'full' },
  { path:'main-page', component:MainPageComponent },
  { path:'user-login', component:UserLoginComponent },
  { path:'mentor-login', component:MentorLoginComponent },
  { path:'admin-login', component:AdminLoginComponent },
  { path:'user-signup', component:UserSignupComponent },
  { path:'mentor-signup', component:MentorSignupComponent },
  { path:'admin-signup', component:AdminSignupComponent },
  { path:'user-landing', component:UserLandingComponent },
  { path:'user-inprogress', component:UserInprogressComponent },
  { path:'user-completed', component:UserCompletedComponent },
  { path:'mentor-landing', component:MentorLandingComponent },
  { path:'mentor-inprogress', component:MentorInprogressComponent },
  { path:'mentor-completed', component:MentorCompletedComponent },
  { path:'mentor-profile', component:MentorProfileComponent },
  { path:'mentor-editskills', component:MentorEditskillsComponent },
  { path:'mentor-payment', component:MentorPaymentComponent },
  { path:'admin-blockuser', component:AdminBlockuserComponent },
  { path:'admin-blockmentor', component:AdminBlockmentorComponent },
  { path:'admin-coursedetails', component:AdminCoursedetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
