import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MainPageComponent } from './main-page/main-page.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminSignupComponent } from './admin-signup/admin-signup.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { UserInprogressComponent } from './user-inprogress/user-inprogress.component';
import { UserCompletedComponent } from './user-completed/user-completed.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { MentorInprogressComponent } from './mentor-inprogress/mentor-inprogress.component';
import { MentorCompletedComponent } from './mentor-completed/mentor-completed.component';
import { MentorEditskillsComponent } from './mentor-editskills/mentor-editskills.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { AdminBlockuserComponent } from './admin-blockuser/admin-blockuser.component';
import { AdminBlockmentorComponent } from './admin-blockmentor/admin-blockmentor.component';
import { AdminCoursedetailsComponent } from './admin-coursedetails/admin-coursedetails.component';
import {HttpClientModule} from '@angular/common/http';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';


@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    MainPageComponent,
    UserSignupComponent,
    MentorLoginComponent,
    MentorSignupComponent,
    AdminLoginComponent,
    AdminSignupComponent,
    UserLandingComponent,
    UserInprogressComponent,
    UserCompletedComponent,
    MentorLandingComponent,
    MentorInprogressComponent,
    MentorCompletedComponent,
    MentorEditskillsComponent,
    MentorProfileComponent,
    AdminBlockuserComponent,
    AdminBlockmentorComponent,
    AdminCoursedetailsComponent,
    MentorPaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
