export class MentorCompleted {
    technology: string;
    duration: number;
}