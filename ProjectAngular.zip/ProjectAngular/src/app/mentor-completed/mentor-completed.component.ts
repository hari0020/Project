import { Component, OnInit } from '@angular/core';
import { MentorCompleted } from '../mentor-completed';
import { Observable } from 'rxjs';
import { UserSignupService } from '../user-signup.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mentor-completed',
  templateUrl: './mentor-completed.component.html',
  styleUrls: ['./mentor-completed.component.css']
})
export class MentorCompletedComponent implements OnInit {
  mentorCompleted: Observable<[MentorCompleted]>;
  mentorname: string;

  constructor(private userService:UserSignupService, private route:ActivatedRoute) { }

  ngOnInit() {
    this.mentorname = this.route.snapshot.paramMap.get('id');
    this.getData();
  }

  getData(): void {
    this.mentorCompleted = this.userService.getCompletedTrainingMentor();
  }

}
