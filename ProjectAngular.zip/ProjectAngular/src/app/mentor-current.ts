export class MentorCurrent {
    technology: string;
    completedduration: number;
    pendingduration: number;
}