import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorEditskillsComponent } from './mentor-editskills.component';

describe('MentorEditskillsComponent', () => {
  let component: MentorEditskillsComponent;
  let fixture: ComponentFixture<MentorEditskillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorEditskillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorEditskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
