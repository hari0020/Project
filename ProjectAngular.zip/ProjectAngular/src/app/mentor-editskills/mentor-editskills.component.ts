import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-mentor-editskills',
  templateUrl: './mentor-editskills.component.html',
  styleUrls: ['./mentor-editskills.component.css']
})
export class MentorEditskillsComponent implements OnInit {
  editskills: string[];

  constructor(private httpservice: HttpClient) { }

  ngOnInit() {
    this.httpservice.get('../../assets/mentor-edit-skills.json').subscribe(
      data => {
        this.editskills = data as string[];
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }

}
