import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorInprogressComponent } from './mentor-inprogress.component';

describe('MentorInprogressComponent', () => {
  let component: MentorInprogressComponent;
  let fixture: ComponentFixture<MentorInprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorInprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorInprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
