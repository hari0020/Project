import { Component, OnInit } from '@angular/core';
import { UserSignupService } from '../user-signup.service';
import { MentorCurrent } from '../mentor-current';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mentor-inprogress',
  templateUrl: './mentor-inprogress.component.html',
  styleUrls: ['./mentor-inprogress.component.css']
})
export class MentorInprogressComponent implements OnInit {
  mentorCurrent: Observable<[MentorCurrent]>;
  mentorname: string;

  constructor(private userService:UserSignupService, private route:ActivatedRoute) { }

  ngOnInit() {
    this.mentorname = this.route.snapshot.paramMap.get('id');
    this.getData();
  }

  getData(): void {
    this.mentorCurrent = this.userService.getCurrentTrainingMentor();
  }

}
