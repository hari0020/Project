import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';


@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {
  email: string;
  pass: string;
  constructor(private mentorlogin: Router) { }

  ngOnInit() {
  }

  submit() {
    if (this.email == null) {
      swal("", "Email is required", "error");
    }
    else if (this.pass == null) {
      swal("", "Password is required", "error");
    }
    else {
      this.mentorlogin.navigate(['/mentor-landing']);
    }
  }

}
