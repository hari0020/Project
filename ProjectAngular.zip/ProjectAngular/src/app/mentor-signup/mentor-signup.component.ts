import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';
import { UserSignupService } from '../user-signup.service';
import { Mentor } from '../mentor';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {
  name: string;
  email: string;
  pass: string;
  pass1: string;
  tel: string;

  mentor:Mentor;

  constructor(private mentorsignup: Router, private userService:UserSignupService) { 
    this.mentor = new Mentor();
  }

  ngOnInit() {
  }

  // submit() {
  //   if (this.name == null) {
  //     swal("", "Name is required", "error");
  //   }
  //   else if (this.email == null) {
  //     swal("", "Email is required", "error");
  //   }
  //   else if (this.pass == null) {
  //     swal("", "Password is required", "error");
  //   }
  //   else if (this.pass != this.pass1) {
  //     swal("", "Password does not match", "error");
  //   }
  //   else if (this.tel.length != 10) {
  //     swal("", "Enter valid telephone number", "error");
  //   }
  //   else {
  //     this.mentorsignup.navigate(['/mentor-login']);
  //   }
  // }

  onSubmit() {

    this.userService.saveMentor(this.mentor).subscribe();
    this.mentorsignup.navigate(['/user-login']);
    // if (this.registerForm.invalid) {
    //   this.usersignup.navigate(['/user-signup']);
    // }
    // else {
    //   this.usersignup.navigate(['/user-login']);
    // }
  }
}
