export class Mentor {
    public username:String;
	public email:String;
	public password:String;
	public confirmPassword:String;
	public contactnumber:number;
	public experience:number;
	public linkedinUrl:String;
	public facilities:String;
}
