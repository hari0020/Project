export class UserCompleted {
    technology: string;
    duration: number;
}