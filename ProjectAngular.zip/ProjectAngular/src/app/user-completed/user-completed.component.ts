import { Component, OnInit } from '@angular/core';
import { UserSignupService } from '../user-signup.service';
import { UserCompleted } from '../user-completed';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { UserCurrent } from '../user-current';

@Component({
  selector: 'app-user-completed',
  templateUrl: './user-completed.component.html',
  styleUrls: ['./user-completed.component.css']
})
export class UserCompletedComponent implements OnInit {

  userCompleted: Observable<[UserCompleted]>;
  username:string;
  course: string[];
  constructor(private userService:UserSignupService, private route:ActivatedRoute) { 
    
  }


  ngOnInit() {
    this.username = this.route.snapshot.paramMap.get('id');
    this.getData();
  }

  getData(): void {
    this.userCompleted = this.userService.getCompletedTraining();
    // this.userService.getCompletedTraining().subscribe(data =>{  
    //   this.course = data as string[];  
    //        })
  }

  

}
