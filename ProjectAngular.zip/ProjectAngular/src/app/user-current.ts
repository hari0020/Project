export class UserCurrent {
    technology:String;
	completedduration:number;
	pendingduration:String;
}