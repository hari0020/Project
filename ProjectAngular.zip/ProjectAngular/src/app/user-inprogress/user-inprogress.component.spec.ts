import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserInprogressComponent } from './user-inprogress.component';

describe('UserInprogressComponent', () => {
  let component: UserInprogressComponent;
  let fixture: ComponentFixture<UserInprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserInprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserInprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
