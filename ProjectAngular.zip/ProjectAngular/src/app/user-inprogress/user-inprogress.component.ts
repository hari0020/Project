import { Component, OnInit, Input } from '@angular/core';
import { UserSignupService } from '../user-signup.service';
import { Observable } from 'rxjs';
import { UserCurrent } from '../user-current';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-inprogress',
  templateUrl: './user-inprogress.component.html',
  styleUrls: ['./user-inprogress.component.css']
})
export class UserInprogressComponent implements OnInit {
  userCurrent: Observable<[UserCurrent]>;
  search: string[];
  // usersearch: boolean;
  // usercurrent: boolean;
  // usercompleted: boolean;
  username:string;
  // user:UserCurrent;
  // @Input() value: number = this.user.completedduration;
  constructor(private userService:UserSignupService, private route:ActivatedRoute) { 
    
  }


  ngOnInit() {
    this.username = this.route.snapshot.paramMap.get('id');
    this.getData();
  }

  getData(): void {
    this.userCurrent = this.userService.getCurrentTraining();
    // this.userService.getCurrentTraining(this.username).subscribe(data =>{  
    //   this.search = data as string[];  
    //        })

    // this.usersearch = false;
    // this.usercurrent = true;
    // this.usercompleted = false;
  }

}
