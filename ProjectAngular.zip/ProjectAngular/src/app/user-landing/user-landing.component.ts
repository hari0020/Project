import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import swal from 'sweetalert';
import { UserSignupService } from '../user-signup.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-landing',
  templateUrl: './user-landing.component.html',
  styleUrls: ['./user-landing.component.css']
})
export class UserLandingComponent implements OnInit {

  constructor(private httpservice: HttpClient, private userService:UserSignupService, private route:ActivatedRoute) { }
  course: string[];
  username : string;
  alertbox() {
    swal("Good job!", "Your request has been sent!", "success");
  }

  ngOnInit() {
    this.username = this.route.snapshot.paramMap.get('id');
    this.httpservice.get('../../assets/coursedetails.json').subscribe(

      data => {
        this.course = data as string[];
      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    )
  }

  myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

}
