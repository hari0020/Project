import { Role } from './role';

export class UserLogin {
    username: string;
    // email: string;
    password: string;
    // confirmPassword: string;
    role: Role;
}