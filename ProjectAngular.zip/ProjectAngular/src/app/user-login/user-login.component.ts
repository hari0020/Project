import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';
import { User } from '../user';
import { UserSignupService } from '../user-signup.service';
import { UserLogin } from '../user-login';
import { FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  model: any = {};
  email: string;
  pass: string;

  formdata;
  user: UserLogin = new UserLogin();

  constructor(private userlogin: Router, private userService:UserSignupService) { }

  ngOnInit() {
    this.formdata = new FormGroup({
      username: new FormControl("", Validators.compose([
         Validators.required,
         Validators.minLength(3)
      ])),
      pwd: new FormControl("", this.passwordvalidation)
   });
}
  passwordvalidation(formcontrol) {
    if (formcontrol.value.length < 5) {
      return {"password" : true};
   }
}


  // submit() {
  //   if (this.email == null) {
  //     swal("", "Email is required", "error");
  //   }
  //   else if (this.pass == null) {
  //     swal("", "Password is required", "error");
  //   }
  //   else {
  //     this.userlogin.navigate(['/user-landing']);
  //   }
  // }

  onSubmit(data) {
    this.userService.logUser(data.username).subscribe(value =>{
      this.user = value})

      if(this.user.password == data.pwd) {
        if(this.user.role.id == 1) {
          this.userlogin.navigate(['/user-landing',{ id: data.username}])
        }
        if(this.user.role.id == 2) {
          this.userlogin.navigate(['/mentor-landing',{ id: data.username}])
        }
        if(this.user.role.id == 3) {
          this.userlogin.navigate(['/admin-blockuser'])
        }
      }
  }
}
