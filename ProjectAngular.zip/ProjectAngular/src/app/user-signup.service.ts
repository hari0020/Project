import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { User } from './user';
import { Mentor } from './mentor';
import { UserCompleted } from './user-completed';

@Injectable({
  providedIn: 'root'
})
export class UserSignupService {
  

  private baseUrl = 'http://localhost:8080/api/'; 

  constructor(private httpClient:HttpClient) { }

  logUser(username: string): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/user/loginuser/${username}`);
  }

  public saveUser(user: User) {  
    return this.httpClient.post(`${this.baseUrl}`+'user/save', user);  
  }  
  
  public saveMentor(mentor:Mentor) {
    return this.httpClient.post(`${this.baseUrl}`+'mentor/save', mentor);
  }

  getCurrentTraining(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}user/findcurrent`);
  }

  getUserDetails(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/admin/finduser`);
  }

  getCompletedTraining(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}user/findcompleted`);
  }

  getCurrentTrainingMentor(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}mentor/findcurrent`);
  }

  getCompletedTrainingMentor(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}mentor/findcompleted`);
  }
}
