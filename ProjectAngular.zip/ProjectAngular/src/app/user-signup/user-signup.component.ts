import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';
import { User } from '../user';
import { UserSignupService } from '../user-signup.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
// import { MustMatch } from './_helpers/must-match.validator';


@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {
  user:User;
  registerForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private usersignup: Router, private userService:UserSignupService) { 
    this.user = new User();
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(5)]],
      confirmPassword: ['', Validators.required]
  }, {
      // validator: MustMatch('password', 'confirmPassword')
  });
  }

  // get f() { return this.registerForm.controls; }

  // onSubmit() {
    // if (this.username == null) {
    //   swal("", "Name is required", "error");
    // }
    // else if (this.email == null) {
    //   swal("", "Email is required", "error");
    // }
    // else if (this.password == null) {
    //   swal("", "Password is required", "error");
    // }
    // else if (this.confirmPassword != this.password) {
    //   swal("", "Password does not match", "error");
    // }
    // else {
    //   this.usersignup.navigate(['/user-login']);
    // }
  //  }

  onSubmit() {

    this.userService.saveUser(this.user).subscribe();
    this.usersignup.navigate(['/user-login']);
    // if (this.registerForm.invalid) {
    //   this.usersignup.navigate(['/user-signup']);
    // }
    // else {
    //   this.usersignup.navigate(['/user-login']);
    // }
  }

}
