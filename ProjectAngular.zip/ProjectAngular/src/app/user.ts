export class User {
    public username:String;
    public email:String;
	public password:String;
	public confirmPassword:String;
}
